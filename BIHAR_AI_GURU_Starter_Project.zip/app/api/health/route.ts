import { NextResponse } from "next/server";
export async function GET() {
  return NextResponse.json({
    app: "BIHAR AI GURU",
    status: "starter-ready",
    integrations: {
      supabase: Boolean(process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY),
      ai: Boolean(process.env.OPENAI_API_KEY)
    },
    message: "Configure environment variables before enabling accounts, syllabus processing and AI tutoring."
  });
}